import random

# Grupp-nr: 24
# Murtaza Karimi, Mohamad Akbar Karimi
# Kurs: GMI35S

def divisableNumbers(firstNum, secondNum):
     output = []
     for i in range(1, 1401):
          if i % firstNum == 0 and i % secondNum == 0:
               output.append(i)
     print(f"Resultat:{output}")

def guessingGame():
     randomNumber = random.randint(1, 41)
     userGuess = ""
     guesses = 0
     while userGuess != randomNumber:   
          try:
               userGuess = int(input("Guess a number between 1-40: "))
               if userGuess > randomNumber:
                   print(f"{userGuess} is Too High!")
               elif userGuess < randomNumber:
                   print(f"{userGuess} is Too Low!")
               guesses += 1
          except ValueError:
               print("Your guess is not a valid guess!")
               print("Try again!")
               continue
     print("Congrats! You guessed the correct number")
     print
     print(f"It took you {guesses} tries to guess the correct number!") if guesses > 1 else print(f"It took you {guesses} try to guess the correct number! WOW!")
     return

