from modules import guessingGame
from modules import divisableNumbers

# Grupp-nr: 24
# Murtaza Karimi, Mohamad Akbar Karimi
# Kurs: GMI35S

while True:
     print("\n### Menu ###")
     print("1. Utför uppgift 1 (Delbara tal mellan 1-1400)")
     print("2. Utför uppgift 2 (Gissningsspel)")
     print("3. Exit")

     try:
          userInput = int(input("Choose an option: "))
     except ValueError:
          print("The input is not valid. Try again!")
          print("Try again later!")
          continue
     if userInput == 1:
          try:
               firstNumber = int(input("Write the first number: "))
               secondNumber = int(input("Write the second number: "))
          except ValueError:
               print("The provided numbers are not valid!")
               continue
          divisableNumbers(firstNumber, secondNumber)
     elif userInput == 2:
          guessingGame()
     elif userInput == 3:
          print("Goodbye!")
          break
     else:
          print(f"{userInput} is not a valid option, (choose 1-3)")

